"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState, type ReactNode } from "react";
import SalaryIncrementTable from "@/components/SalaryIncrementTable";
import EmployeeLoanLedger from "@/components/EmployeeLoanLedger";

const ADMIN_DELETE_PASSWORD = "admin123";

const TABS = [
  "Personal Information",
  "Salary and Benefits",
  "Leave Details",
  "Office Documents",
  "Immigration Documents",
  "Personal Documents",
  "ICDE Forms",
  "HAAD",
] as const;

type TabName = (typeof TABS)[number];

export default function EmployeeProfilePage({
  params,
}: {
  params: Promise<{ id: string }> | { id: string };
}) {
  const [id, setId] = useState("");
  const [employee, setEmployee] = useState<any>(null);
  const [documents, setDocuments] = useState<any[]>([]);
  const [annualLeaveSummary, setAnnualLeaveSummary] = useState({
    used: 0,
    balance: 0,
  });
  const [activeTab, setActiveTab] = useState<TabName>("Personal Information");

  useEffect(() => {
    const requestedTab = new URLSearchParams(
      window.location.search
    ).get("tab") as TabName | null;

    if (requestedTab && TABS.includes(requestedTab)) {
      setActiveTab(requestedTab);
    }
  }, []);
  const [editMode, setEditMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingFormDocument, setEditingFormDocument] =
    useState<any>(null);
  const [editingFormName, setEditingFormName] =
    useState("");
  const [editingFormFile, setEditingFormFile] =
    useState({
      file_name: "",
      file_type: "",
      file_data: "",
    });

  const [docForm, setDocForm] = useState({
    document_name: "",
    category: "Office Documents",
    issue_date: "",
    expiry_date: "",
    not_applicable: false,
    file_name: "",
    file_type: "",
    file_data: "",
  });

  useEffect(() => {
    Promise.resolve(params).then((p) => {
      setId(p.id);
      loadEmployee(p.id);
      loadDocuments(p.id);
    });
  }, [params]);

  async function loadEmployee(employeeId: string) {
    const [employeeResponse, leaveResponse] = await Promise.all([
      fetch(`/api/employees/${employeeId}`, {
        cache: "no-store",
      }),
      fetch("/api/leave-requests", {
        cache: "no-store",
      }),
    ]);

    const employeeData = await employeeResponse.json();
    const leaveData = await leaveResponse.json();

    setEmployee(employeeData);

    const annualGroupTypes = [
      "Annual Leave",
      "Sick Leave",
      "Emergency Leave",
  "Encash Leave",
    ];

    const approvedAnnualRequests = Array.isArray(leaveData)
      ? leaveData.filter((request: any) => {
          return (
            String(request.employee_id) === String(employeeId) &&
            String(request.status).toLowerCase() === "approved" &&
            annualGroupTypes.includes(
              String(request.leave_type)
            )
          );
        })
      : [];

    const used = approvedAnnualRequests.reduce(
      (total: number, request: any) =>
        total + Number(request.total_days || 0),
      0
    );

    const entitlement = Number(
      employeeData.total_leaves ?? 0
    );

    setAnnualLeaveSummary({
      used,
      balance: Math.max(entitlement - used, 0),
    });
  }

  async function testAsEmployee() {
    const confirmed = window.confirm(
      `Open the Staff Portal for ${fullName || "this employee"}? Any submitted actions will create real records.`
    );

    if (!confirmed) return;

    const response = await fetch(
      "/api/auth/test-as-employee",
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify({
          employee_id: id,
        }),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      alert(
        result.error ||
          "Unable to start testing mode."
      );
      return;
    }

    localStorage.setItem(
      "icde_user_id",
      id
    );

    localStorage.setItem(
      "icde_user_role",
      "Staff"
    );

    window.location.href = "/staff";
  }

  async function resetEmployeePassword() {
    const username =
      employee.login_username ||
      "No username assigned";

    const newPassword =
      window.prompt(
        `Username: ${username}\n\nEnter a temporary password of at least 8 characters:`
      );

    if (newPassword === null) {
      return;
    }

    if (newPassword.length < 8) {
      alert(
        "Password must be at least 8 characters."
      );
      return;
    }

    const confirmPassword =
      window.prompt(
        "Confirm the temporary password:"
      );

    if (confirmPassword === null) {
      return;
    }

    if (
      newPassword !==
      confirmPassword
    ) {
      alert(
        "Passwords do not match."
      );
      return;
    }

    const confirmed =
      window.confirm(
        `Reset the password for ${fullName || username}?\n\nThe employee will be required to change it after login.`
      );

    if (!confirmed) {
      return;
    }

    const response = await fetch(
      "/api/auth/admin-reset-password",
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify({
          employeeId: id,
          newPassword,
          confirmPassword,
        }),
      }
    );

    const result =
      await response.json();

    if (!response.ok) {
      alert(
        result.error ||
          "Unable to reset password."
      );
      return;
    }

    alert(
      `Password reset successfully.\n\nUsername: ${username}\n\nGive the temporary password to the employee securely. The employee must change it after login.`
    );
  }

  async function loadDocuments(employeeId: string) {
    const data = await fetch(`/api/employee-documents?employee_id=${employeeId}`).then((r) => r.json());
    setDocuments(Array.isArray(data) ? data : []);
  }

  function update(field: string, value: any) {
    setEmployee((prev: any) => ({ ...prev, [field]: value }));
  }

  async function saveChanges() {
    setSaving(true);

    const res = await fetch(`/api/employees/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(employee),
    });

    const result = await res.json();

    if (!res.ok) {
      alert(result.error || "Failed to update employee");
      setSaving(false);
      return;
    }

    setEmployee(result);
    setEditMode(false);
    setSaving(false);
    alert("Employee profile updated successfully");
  }

  async function deleteSalary() {
    const confirmed = window.confirm(
      "Delete this employee salary information?"
    );

    if (!confirmed) return;

    setSaving(true);

    const salaryReset = {
      basic_salary: 0,
      accommodation_allowance: 0,
      transportation_allowance: 0,
    };

    const response = await fetch(`/api/employees/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(salaryReset),
    });

    const result = await response.json();

    if (!response.ok) {
      alert(result.error || "Failed to delete salary information.");
      setSaving(false);
      return;
    }

    setEmployee((current: any) => ({
      ...current,
      ...salaryReset,
    }));

    setEditMode(false);
    setSaving(false);
    alert("Salary information deleted successfully.");
  }

  async function toggleStatus() {
    const nextStatus = (employee.status || "Available") === "On Leave" ? "Available" : "On Leave";

    await fetch(`/api/employees/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });

    location.reload();
  }

  async function deleteEmployee() {
    if (!confirm("Delete this employee permanently?")) return;

    await fetch(`/api/employees/${id}`, { method: "DELETE" });
    window.location.href = "/employees";
  }

  async function handlePhotoUpload(file: File | null) {
    if (!file) return;

    const reader = new FileReader();

    reader.onload = async () => {
      const photoData = String(reader.result || "");

      const res = await fetch(`/api/employees/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile_photo: photoData }),
      });

      const result = await res.json();

      if (!res.ok) return alert(result.error || "Failed to upload photo");

      setEmployee(result);
      alert("Profile photo updated successfully");
    };

    reader.readAsDataURL(file);
  }

  async function removePhoto() {
    const res = await fetch(`/api/employees/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ profile_photo: null }),
    });

    const result = await res.json();

    if (!res.ok) return alert(result.error || "Failed to remove photo");

    setEmployee(result);
    alert("Profile photo removed successfully");
  }

  function handleFile(file: File | null) {
    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {
      setDocForm((prev) => ({
        ...prev,
        file_name: file.name,
        file_type: file.type || "application/octet-stream",
        file_data: String(reader.result || ""),
      }));
    };

    reader.readAsDataURL(file);
  }

  async function uploadDocument(categoryOverride?: string) {
    if (!docForm.document_name) return alert("Please enter document name.");
    if (!docForm.file_data) return alert("Please choose a file.");

    const res = await fetch("/api/employee-documents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        employee_id: id,
        document_name: docForm.document_name,
        category: categoryOverride || docForm.category,
        issue_date: docForm.not_applicable ? null : docForm.issue_date || null,
        expiry_date: docForm.not_applicable ? null : docForm.expiry_date || null,
        file_name: docForm.file_name,
        file_type: docForm.file_type,
        file_data: docForm.file_data,
        status: "Available",
      }),
    });

    const result = await res.json();

    if (!res.ok) return alert(result.error || "Failed to upload document");

    setDocForm({
      document_name: "",
      category: categoryOverride || "Office Documents",
      issue_date: "",
      expiry_date: "",
      not_applicable: false,
      file_name: "",
      file_type: "",
      file_data: "",
    });

    await loadDocuments(id);
    alert("Document uploaded successfully");
  }

  function openEditICDEForm(document: any) {
    setEditingFormDocument(document);
    setEditingFormName(
      document.document_name || ""
    );

    setEditingFormFile({
      file_name:
        document.file_name || "",
      file_type:
        document.file_type || "",
      file_data:
        document.file_data || "",
    });
  }

  function handleEditICDEFormFile(
    file: File | null
  ) {
    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {
      setEditingFormFile({
        file_name: file.name,
        file_type:
          file.type ||
          "application/octet-stream",
        file_data:
          String(reader.result || ""),
      });
    };

    reader.readAsDataURL(file);
  }

  async function saveEditedICDEForm() {
    if (!editingFormDocument?.id) return;

    if (!editingFormName.trim()) {
      alert("Please enter document name.");
      return;
    }

    const res = await fetch(
      `/api/employee-documents/${editingFormDocument.id}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          document_name:
            editingFormName.trim(),
          file_name:
            editingFormFile.file_name,
          file_type:
            editingFormFile.file_type,
          file_data:
            editingFormFile.file_data,
        }),
      }
    );

    const result = await res.json();

    if (!res.ok) {
      alert(
        result.error ||
          "Failed to update ICDE Form."
      );
      return;
    }

    setEditingFormDocument(null);
    setEditingFormName("");
    setEditingFormFile({
      file_name: "",
      file_type: "",
      file_data: "",
    });

    await loadDocuments(id);

    alert("ICDE Form updated successfully.");
  }

  async function deleteDocument(documentId: string) {
    const password = prompt("Enter Admin password to delete this document:");

    if (password !== ADMIN_DELETE_PASSWORD) {
      return alert("Wrong password. Document was not deleted.");
    }

    if (!confirm("Delete this document permanently?")) return;

    const res = await fetch(`/api/employee-documents/${documentId}`, {
      method: "DELETE",
    });

    if (!res.ok) {
      const result = await res.json();
      return alert(result.error || "Failed to delete document");
    }

    await loadDocuments(id);
    alert("Document deleted successfully");
  }

  if (!employee) return <div className="p-10">Loading...</div>;

  const fullName = `${employee.first_name || ""} ${employee.middle_name || ""} ${employee.last_name || ""}`
    .replace(/\s+/g, " ")
    .trim();

  const initials = `${employee.first_name?.[0] || ""}${employee.last_name?.[0] || ""}`.toUpperCase();

  return (
    <div className="min-h-screen bg-[#f7f4ec] flex">
      <Sidebar />

      <main className="flex-1 p-8 overflow-x-hidden">
        <a href="/employees" className="text-[#d2b241] font-semibold">
          ← Back to Employees
        </a>

        <section className="mt-8 mb-6 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
          <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px] xl:items-center">
            <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
              <div className="shrink-0">
                <div className="flex h-32 w-32 items-center justify-center overflow-hidden rounded-2xl bg-[#3f4447] text-4xl font-bold text-white">
                  {employee.profile_photo ? (
                    <img
                      src={employee.profile_photo}
                      alt="Employee Photo"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    initials
                  )}
                </div>

                <label className="mt-3 block cursor-pointer rounded-xl bg-[#d2b241] px-3 py-2 text-center text-sm font-semibold text-white">
                  Upload Photo
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(event) =>
                      handlePhotoUpload(
                        event.target.files?.[0] || null
                      )
                    }
                  />
                </label>

                {employee.profile_photo && (
                  <button
                    onClick={removePhoto}
                    className="mt-2 w-full rounded-xl bg-red-100 px-3 py-2 text-sm font-semibold text-red-700"
                  >
                    Remove Photo
                  </button>
                )}
              </div>

              <div className="min-w-0">
                <h1 className="text-3xl font-bold text-[#3f4447]">
                  {fullName}
                </h1>

                <p className="mt-4 text-gray-500">
                  Employee ID: {employee.employee_code}
                </p>

                <p className="mt-2 text-gray-500">
                  Date of Joining: {employee.joining_date || "-"}
                </p>

                <span
                  className={`mt-4 inline-block rounded-full px-4 py-2 font-semibold ${
                    (employee.status || "Available") === "On Leave"
                      ? "bg-red-100 text-red-700"
                      : "bg-green-100 text-green-700"
                  }`}
                >
                  {employee.status || "Available"}
                </span>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6 xl:border-l xl:border-t-0 xl:pl-8 xl:pt-0">
              <div className="grid gap-3">
                {editMode ? (
                  <>
                    <button
                      onClick={() => setEditMode(false)}
                      className="w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 font-semibold text-gray-700"
                    >
                      Cancel Edit
                    </button>

                    <button
                      onClick={saveChanges}
                      disabled={saving}
                      className="w-full rounded-xl border border-[#d2b241] bg-[#d2b241] px-4 py-3 font-semibold text-white"
                    >
                      {saving ? "Saving..." : "Save Changes"}
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setEditMode(true)}
                    className="w-full rounded-xl border border-[#d2b241] bg-[#fffaf0] px-4 py-3 font-semibold text-[#9a7410]"
                  >
                    Edit Profile
                  </button>
                )}

                <button
                  onClick={resetEmployeePassword}
                  className="w-full rounded-xl border border-blue-400 bg-blue-50 px-4 py-3 font-semibold text-blue-700"
                >
                  Reset Employee Password
                </button>

                <button
                  onClick={testAsEmployee}
                  className="w-full rounded-xl border border-purple-400 bg-purple-50 px-4 py-3 font-semibold text-purple-700"
                >
                  Login as Employee for Testing
                </button>

                <button
                  onClick={toggleStatus}
                  className={`w-full rounded-xl border px-4 py-3 font-semibold ${
                    (employee.status || "Available") === "On Leave"
                      ? "border-green-400 bg-green-50 text-green-700"
                      : "border-orange-400 bg-orange-50 text-orange-700"
                  }`}
                >
                  {(employee.status || "Available") === "On Leave"
                    ? "Activate"
                    : "Deactivate"}
                </button>

                <button
                  onClick={deleteEmployee}
                  className="w-full rounded-xl border border-red-400 bg-red-50 px-4 py-3 font-semibold text-red-700"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-6 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
          <div className="flex flex-wrap gap-2">
            {TABS.filter(
              (tab) =>
                tab !== "HAAD" ||
                ["Clinicians", "Dental Assistant"].includes(
                  employee.department || ""
                )
            ).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-3 rounded-xl font-semibold text-sm border transition-all ${
                  activeTab === tab
                    ? "bg-[#d2b241] text-white border-[#b99316] shadow-sm"
                    : tab === "Personal Information"
                    ? "bg-[#efe7ff] text-[#5b21b6] border-[#c4b5fd] hover:bg-[#ddd6fe]"
                    : tab === "Salary and Benefits"
                    ? "bg-[#fef3c7] text-[#92400e] border-[#fbbf24] hover:bg-[#fde68a]"
                    : tab === "Leave Details"
                    ? "bg-[#dcfce7] text-[#166534] border-[#86efac] hover:bg-[#bbf7d0]"
                    : tab === "Office Documents"
                    ? "bg-[#e0f2fe] text-[#075985] border-[#7dd3fc] hover:bg-[#bae6fd]"
                    : tab === "Immigration Documents"
                    ? "bg-[#d1fae5] text-[#047857] border-[#6ee7b7] hover:bg-[#a7f3d0]"
                    : "bg-[#f3e8ff] text-[#7e22ce] border-[#d8b4fe] hover:bg-[#e9d5ff]"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </section>

        {activeTab === "Personal Information" &&
  (editMode ? (
    <EditSection title="Personal Information">
      <EditInput
        label="Employee ID"
        field="employee_code"
        value={employee.employee_code}
        update={update}
      />
      <EditInput
        label="First Name"
        field="first_name"
        value={employee.first_name}
        update={update}
      />
      <EditInput
        label="Middle Name"
        field="middle_name"
        value={employee.middle_name}
        update={update}
      />
      <EditInput
        label="Last Name"
        field="last_name"
        value={employee.last_name}
        update={update}
      />
      <EditInput
        label="Date of Birth"
        field="date_of_birth"
        type="date"
        value={employee.date_of_birth}
        update={update}
      />
      <EditSelect
        label="Gender"
        field="gender"
        value={employee.gender}
        options={["Male", "Female"]}
        update={update}
      />
      <EditInput
        label="Nationality"
        field="nationality"
        value={employee.nationality}
        update={update}
      />
      <EditInput
        label="Mobile Number"
        field="mobile_number"
        value={employee.mobile_number}
        update={update}
      />
      <EditInput
        label="Email Address"
        field="email"
        value={employee.email}
        update={update}
      />
      <EditInput
        label="UAE Address"
        field="uae_address"
        value={employee.uae_address}
        update={update}
      />
    </EditSection>
  ) : (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <h2 className="text-xl font-bold text-[#3f4447] mb-5">
        Personal Information (1 of 2)
      </h2>

      <div className="overflow-x-auto">
        <table className="min-w-[1500px] w-full border border-gray-200">
          <thead className="bg-[#d2b241] text-white">
            <tr>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Employee ID</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Full Name</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Mobile Number</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Email</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Date of Birth</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Nationality</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Gender</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Resident Address</th>
            </tr>
          </thead>

          <tbody>
            <tr className="border-t">
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.employee_code || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{fullName || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.mobile_number || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.email || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.date_of_birth || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.nationality || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.gender || "-"}</td>
              <td className="px-2 py-2 whitespace-nowrap text-sm">{employee.uae_address || "-"}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
 
  ))}

        {activeTab === "Salary and Benefits" && (
          <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
              <h2 className="text-xl font-bold text-[#3f4447]">
                Salary & Benefits
              </h2>

              <div className="flex flex-wrap gap-3">
                {editMode ? (
                  <>
                    <button
                      type="button"
                      onClick={saveChanges}
                      disabled={saving}
                      className="bg-[#d2b241] text-white px-4 py-2 rounded-lg font-bold disabled:opacity-50"
                    >
                      {saving ? "Saving..." : "Save Salary"}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setEditMode(false);
                        loadEmployee(id);
                      }}
                      className="bg-gray-200 text-[#3f4447] px-4 py-2 rounded-lg font-bold"
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => setEditMode(true)}
                      className="bg-[#d2b241] text-white px-4 py-2 rounded-lg font-bold"
                    >
                      {Number(employee.basic_salary || 0) === 0 &&
                      Number(employee.accommodation_allowance || 0) === 0 &&
                      Number(employee.transportation_allowance || 0) === 0
                        ? "+ Add Salary"
                        : "Edit Salary"}
                    </button>

                    <button
                      type="button"
                      onClick={deleteSalary}
                      disabled={saving}
                      className="bg-red-600 text-white px-4 py-2 rounded-lg font-bold disabled:opacity-50"
                    >
                      Delete Salary
                    </button>
                  </>
                )}
              </div>
            </div>

            <div className="overflow-x-auto border rounded-xl">
              <table className="min-w-[1100px] w-full text-sm">
                <thead>
                  <tr className="bg-[#d2b241] text-white">
                    <th className="p-4 text-left">ID</th>
                    <th className="p-4 text-left">Name</th>
                    <th className="p-4 text-left">Department</th>
                    <th className="p-4 text-left">Basic Salary</th>
                    <th className="p-4 text-left">Accommodation</th>
                    <th className="p-4 text-left">Transportation</th>
                    <th className="p-4 text-left">Total</th>
                  </tr>
                </thead>

                <tbody>
                  <tr className="border-t">
                    <td className="p-4 whitespace-nowrap">
                      {employee.employee_code || "-"}
                    </td>

                    <td className="p-4 whitespace-nowrap">
                      {fullName || "-"}
                    </td>

                    <td className="p-4 whitespace-nowrap">
                      {employee.department || "-"}
                    </td>

                    <td className="p-4">
                      {editMode ? (
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={employee.basic_salary || ""}
                          onChange={(event) =>
                            update("basic_salary", event.target.value)
                          }
                          className="w-full min-w-[140px] border rounded-lg px-3 py-2"
                        />
                      ) : (
                        `AED ${Number(employee.basic_salary || 0).toLocaleString()}`
                      )}
                    </td>

                    <td className="p-4">
                      {editMode ? (
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={employee.accommodation_allowance || ""}
                          onChange={(event) =>
                            update(
                              "accommodation_allowance",
                              event.target.value
                            )
                          }
                          className="w-full min-w-[140px] border rounded-lg px-3 py-2"
                        />
                      ) : (
                        `AED ${Number(
                          employee.accommodation_allowance || 0
                        ).toLocaleString()}`
                      )}
                    </td>

                    <td className="p-4">
                      {editMode ? (
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={employee.transportation_allowance || ""}
                          onChange={(event) =>
                            update(
                              "transportation_allowance",
                              event.target.value
                            )
                          }
                          className="w-full min-w-[140px] border rounded-lg px-3 py-2"
                        />
                      ) : (
                        `AED ${Number(
                          employee.transportation_allowance || 0
                        ).toLocaleString()}`
                      )}
                    </td>

                    <td className="p-4 font-bold text-[#3f4447] whitespace-nowrap">
                      AED{" "}
                      {(
                        Number(employee.basic_salary || 0) +
                        Number(employee.accommodation_allowance || 0) +
                        Number(employee.transportation_allowance || 0)
                      ).toLocaleString()}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        )}

        {activeTab === "Salary and Benefits" && (
          <SalaryIncrementTable
            employeeId={id}
            currentSalary={
              Number(employee.basic_salary || 0) +
              Number(employee.accommodation_allowance || 0) +
              Number(employee.transportation_allowance || 0)
            }
            onSalaryChanged={() => loadEmployee(id)}
          />
        )}

        {activeTab === "Salary and Benefits" && (
          <EmployeeLoanLedger
            employeeId={id}
          />
        )}

        {activeTab === "Leave Details" && (
  <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
    <h2 className="text-xl font-bold text-[#3f4447] mb-6">
      Leave Summary
    </h2>

    <div className="space-y-6">
      <div className="rounded-2xl border border-gray-100 p-5">
        <h3 className="text-lg font-bold text-[#3f4447] mb-4">
          Annual Leave
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <MiniKpi
              title="Total"
              value={`${employee.total_leaves ?? 0} Days`}
              onClick={() => {
                window.location.href =
                  `/employees/${id}/annual-leave-register`;
              }}
            />
          <MiniKpi
  title="Used"
  value={`${annualLeaveSummary.used} Days`}
  onClick={() =>
    window.location.href = `/employees/${id}/leave-ledger?type=annual`
  }
/>
          <MiniKpi
            title="Balance"
            value={`${annualLeaveSummary.balance} Days`}
          />
        </div>
      </div>

      {String(employee.gender || "")
        .trim()
        .toLowerCase() === "male" && (
      <div className="rounded-2xl border border-gray-100 p-5">
        <h3 className="text-lg font-bold text-[#3f4447] mb-4">
          Paternity Leave
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <MiniKpi
  title="Total"
  value={`${employee.paternity_leave_total ?? 0} Days`}
  onClick={() =>
    window.location.href = `/employees/${id}/paternity-leave-register`
  }
/>
          <MiniKpi
            title="Used"
            value={`${employee.paternity_leave_used ?? 0} Days`}
              onClick={() =>
                window.location.href = `/employees/${id}/leave-ledger?type=paternity`
              }
          />
          <MiniKpi
            title="Balance"
            value={`${employee.paternity_leave_balance ?? 0} Days`}
          />
        </div>
      </div>
      )}

      {String(employee.gender || "")
        .trim()
        .toLowerCase() === "female" && (
      <div className="rounded-2xl border border-gray-100 p-5">
        <h3 className="text-lg font-bold text-[#3f4447] mb-4">
          Maternity Leave
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <MiniKpi
  title="Total"
  value={`${employee.maternity_leave_total ?? 0} Days`}
  onClick={() =>
    window.location.href = `/employees/${id}/maternity-leave-register`
  }
/>
          <MiniKpi
            title="Used"
            value={`${employee.maternity_leave_used ?? 0} Days`}
              onClick={() =>
                window.location.href = `/employees/${id}/leave-ledger?type=maternity`
              }
          />
          <MiniKpi
            title="Balance"
            value={`${employee.maternity_leave_balance ?? 0} Days`}
          />
        </div>
      </div>
      )}

      <div className="rounded-2xl border border-gray-100 p-5">
        <h3 className="text-lg font-bold text-[#3f4447] mb-4">
          Holiday Credit Leave
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <MiniKpi
            title="Earned"
            value={`${employee.credit_leave_earned ?? 0} Days`}
              onClick={() =>
                window.location.href = `/employees/${id}/holiday-credit-ledger`
              }
          />
          <MiniKpi
            title="Used"
            value={`${employee.credit_leave_used ?? 0} Days`}
              onClick={() =>
                window.location.href = `/employees/${id}/holiday-credit-ledger`
              }
          />
          <MiniKpi
            title="Balance"
            value={`${employee.credit_leave_balance ?? 0} Days`}
          />
        </div>
      </div>

      <div className="rounded-2xl border border-gray-100 p-5">
        <h3 className="text-lg font-bold text-[#3f4447] mb-4">
          Unpaid Leave
        </h3>

        <MiniKpi
          title="Used"
          value={`${employee.unpaid_leave_used ?? 0} Days`}
        />
      </div>
    </div>
  </section>
)}

        {activeTab === "Office Documents" && (
          <DocumentCenter category="Office Documents" docForm={docForm} setDocForm={setDocForm} handleFile={handleFile} uploadDocument={uploadDocument} documents={documents} deleteDocument={deleteDocument} />
        )}

        {activeTab === "Immigration Documents" && (
          <DocumentCenter category="Immigration Documents" docForm={docForm} setDocForm={setDocForm} handleFile={handleFile} uploadDocument={uploadDocument} documents={documents} deleteDocument={deleteDocument} />
        )}

        {activeTab === "Personal Documents" && (
          <DocumentCenter category="Personal Documents" docForm={docForm} setDocForm={setDocForm} handleFile={handleFile} uploadDocument={uploadDocument} documents={documents} deleteDocument={deleteDocument} />
        )}

        {activeTab === "ICDE Forms" && (
          <ICDEFormsCenter
            category="ICDE Forms"
            title="ICDE Forms"
            description="Admin-only employee forms and internal documents."
            docForm={docForm}
            setDocForm={setDocForm}
            handleFile={handleFile}
            uploadDocument={uploadDocument}
            documents={documents}
            deleteDocument={deleteDocument}
            openEditICDEForm={openEditICDEForm}
            editingFormDocument={
              editingFormDocument
            }
            editingFormName={
              editingFormName
            }
            setEditingFormName={
              setEditingFormName
            }
            editingFormFile={
              editingFormFile
            }
            handleEditICDEFormFile={
              handleEditICDEFormFile
            }
            saveEditedICDEForm={
              saveEditedICDEForm
            }
            cancelEdit={() => {
              setEditingFormDocument(null);
              setEditingFormName("");
              setEditingFormFile({
                file_name: "",
                file_type: "",
                file_data: "",
              });
            }}
          />
        )}

        {activeTab === "HAAD" &&
          ["Clinicians", "Dental Assistant"].includes(
            employee.department || ""
          ) && (
            <ICDEFormsCenter
              category="HAAD"
              title="HAAD"
              description="HAAD licensing, approval, credential, and related employee documents."
              docForm={docForm}
              setDocForm={setDocForm}
              handleFile={handleFile}
              uploadDocument={uploadDocument}
              documents={documents}
              deleteDocument={deleteDocument}
              openEditICDEForm={openEditICDEForm}
              editingFormDocument={editingFormDocument}
              editingFormName={editingFormName}
              setEditingFormName={setEditingFormName}
              editingFormFile={editingFormFile}
              handleEditICDEFormFile={handleEditICDEFormFile}
              saveEditedICDEForm={saveEditedICDEForm}
              cancelEdit={() => {
                setEditingFormDocument(null);
                setEditingFormName("");
                setEditingFormFile({
                  file_name: "",
                  file_type: "",
                  file_data: "",
                });
              }}
            />
          )}

        <AuditSection status={employee.status || "Available"} />
      </main>
    </div>
  );
}

function Sidebar() {
  return (
    <aside className="w-72 shrink-0 bg-[#3f4447] text-white p-6 hidden md:flex flex-col justify-between">
      <div>
        <div className="mb-10">
          <div className="text-4xl font-black tracking-widest">
            <span className="text-white">IC</span><span className="text-[#d2b241]">D</span><span className="text-white">E</span>
          </div>
          <div className="text-sm text-white/90 mt-3">HR Management Portal</div>
          <div className="w-24 h-[3px] bg-[#d2b241] mt-3 rounded-full"></div>
          <div className="text-xs text-white/60 mt-3">©2026 V.1.1</div>
        </div>

        <nav className="space-y-3">
          <a href="/dashboard" className="block px-4 py-3 rounded-xl hover:bg-white/10">Dashboard</a>
          <a href="/employees" className="block px-4 py-3 rounded-xl bg-[#d2b241] font-semibold">Employees</a>
          <a href="/leave-requests" className="block px-4 py-3 rounded-xl hover:bg-white/10">Leave Requests</a>
          <a href="/document-expiry" className="block px-4 py-3 rounded-xl hover:bg-white/10">Document Expiry</a>
          <a href="/reports" className="block px-4 py-3 rounded-xl hover:bg-white/10">Reports</a>
        </nav>
      </div>

      <button
        onClick={() => {
          localStorage.clear();
          document.cookie = "icde_auth=; path=/; max-age=0";
          window.location.href = "/logout";
        }

}
        className="w-full rounded-2xl border border-white/25 py-4 text-white font-semibold hover:bg-white/10"
      >
        Sign Out
      </button>
    </aside>
  );
}

function ICDEFormsCenter({
  category,
  title,
  description,
  docForm,
  setDocForm,
  handleFile,
  uploadDocument,
  documents,
  deleteDocument,
  openEditICDEForm,
  editingFormDocument,
  editingFormName,
  setEditingFormName,
  editingFormFile,
  handleEditICDEFormFile,
  saveEditedICDEForm,
  cancelEdit,
}: any) {
  const rows = documents.filter(
    (document: any) =>
      document.category === category
  );

  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <div className="mb-5">
        <h2 className="text-xl font-bold text-[#3f4447]">
          {title}
        </h2>

        <p className="text-gray-500 text-sm mt-1">
          {description}
        </p>
      </div>

      <div className="bg-[#f7f4ec] rounded-2xl p-5 mb-6">
        <h3 className="font-bold text-[#3f4447] mb-4">
          Upload New Document
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Document Name"
            value={docForm.document_name}
            onChange={(value: string) =>
              setDocForm({
                ...docForm,
                document_name: value,
                category,
              })
            }
          />

          <div>
            <label className="text-sm font-semibold text-gray-600">
              Upload Picture or File
            </label>

            <input
              type="file"
              accept="image/*,.pdf,.doc,.docx"
              onChange={(event) =>
                handleFile(
                  event.target.files?.[0] ||
                    null
                )
              }
              className="mt-2 w-full border rounded-xl px-4 py-3 bg-white"
            />

            {docForm.file_name ? (
              <p className="text-xs text-green-700 mt-1">
                Selected: {docForm.file_name}
              </p>
            ) : null}
          </div>
        </div>

        <button
          type="button"
          onClick={() =>
            uploadDocument(category)
          }
          className="mt-5 bg-[#d2b241] text-white px-5 py-3 rounded-xl font-semibold"
        >
          Upload Document
        </button>
      </div>

      {editingFormDocument ? (
        <div className="border border-[#d2b241] rounded-2xl p-5 mb-6">
          <h3 className="font-bold text-[#3f4447] mb-4">
            Edit Document
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Document Name"
              value={editingFormName}
              onChange={
                setEditingFormName
              }
            />

            <div>
              <label className="text-sm font-semibold text-gray-600">
                Replace Picture or File
              </label>

              <input
                type="file"
                accept="image/*,.pdf,.doc,.docx"
                onChange={(event) =>
                  handleEditICDEFormFile(
                    event.target.files?.[0] ||
                      null
                  )
                }
                className="mt-2 w-full border rounded-xl px-4 py-3 bg-white"
              />

              {editingFormFile.file_name ? (
                <p className="text-xs text-green-700 mt-1">
                  Current:{" "}
                  {editingFormFile.file_name}
                </p>
              ) : null}
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-5">
            <button
              type="button"
              onClick={cancelEdit}
              className="bg-gray-200 text-[#3f4447] px-5 py-3 rounded-xl font-bold"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={
                saveEditedICDEForm
              }
              className="bg-[#3f4447] text-white px-5 py-3 rounded-xl font-bold"
            >
              Save Changes
            </button>
          </div>
        </div>
      ) : null}

      <div className="overflow-x-auto border rounded-xl">
        <table className="min-w-[760px] w-full text-sm">
          <thead>
            <tr className="bg-[#d2b241] text-white">
              <th className="p-4 text-left">
                Document Name
              </th>

              <th className="p-4 text-left">
                Uploaded File
              </th>

              <th className="p-4 text-center">
                View
              </th>

              <th className="p-4 text-center">
                Edit
              </th>

              <th className="p-4 text-center">
                Delete
              </th>
            </tr>
          </thead>

          <tbody>
            {rows.length ? (
              rows.map((document: any) => (
                <tr
                  key={document.id}
                  className="border-b hover:bg-[#f7f4ec]"
                >
                  <td className="p-4 font-semibold">
                    {document.document_name}
                  </td>

                  <td className="p-4">
                    {document.file_name || "-"}
                  </td>

                  <td className="p-4 text-center">
                    {document.file_data ? (
                      <button
                        type="button"
                        onClick={() =>
                          previewDoc(document)
                        }
                        className="text-[#d2b241] font-bold hover:underline"
                      >
                        View
                      </button>
                    ) : (
                      "-"
                    )}
                  </td>

                  <td className="p-4 text-center">
                    <button
                      type="button"
                      onClick={() =>
                        openEditICDEForm(
                          document
                        )
                      }
                      className="text-blue-700 font-bold hover:underline"
                    >
                      Edit
                    </button>
                  </td>

                  <td className="p-4 text-center">
                    <button
                      type="button"
                      onClick={() =>
                        deleteDocument(
                          document.id
                        )
                      }
                      className="text-red-700 font-bold hover:underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={5}
                  className="p-8 text-center text-gray-500"
                >
                  No ICDE forms uploaded yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function DocumentCenter({ category, docForm, setDocForm, handleFile, uploadDocument, documents, deleteDocument }: any) {
  const rows = documents.filter((d: any) => d.category === category);

  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <div className="mb-5">
        <h2 className="text-xl font-bold text-[#3f4447]">{category}</h2>
        <p className="text-gray-500 text-sm">Upload, preview, download, and protected delete.</p>
      </div>

      <div className="bg-[#f7f4ec] rounded-2xl p-5 mb-6">
        <h3 className="font-bold text-[#3f4447] mb-4">Upload New Document</h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input label="Document Name" value={docForm.document_name} onChange={(v: string) => setDocForm({ ...docForm, document_name: v })} />
          <Select label="Section / Category" value={category} options={[category]} onChange={() => setDocForm({ ...docForm, category })} />

          <div>
            <label className="text-sm font-semibold text-gray-600">Upload File</label>
            <input type="file" onChange={(e) => handleFile(e.target.files?.[0] || null)} className="mt-2 w-full border rounded-xl px-4 py-3 bg-white" />
            {docForm.file_name && <p className="text-xs text-green-700 mt-1">Selected: {docForm.file_name}</p>}
          </div>

          <Input label="Date of Issue" type="date" value={docForm.issue_date} onChange={(v: string) => setDocForm({ ...docForm, issue_date: v })} />
          <Input label="Date of Expiry" type="date" value={docForm.expiry_date} onChange={(v: string) => setDocForm({ ...docForm, expiry_date: v })} />

          <label className="flex items-center gap-3 bg-white rounded-xl border px-4 py-3 mt-7">
            <input
              type="checkbox"
              checked={docForm.not_applicable}
              onChange={(e) =>
                setDocForm({
                  ...docForm,
                  not_applicable: e.target.checked,
                  issue_date: e.target.checked ? "" : docForm.issue_date,
                  expiry_date: e.target.checked ? "" : docForm.expiry_date,
                })
              }
            />
            <span className="font-semibold text-[#3f4447]">Not Applicable</span>
          </label>
        </div>

        <button onClick={() => uploadDocument(category)} className="mt-5 bg-[#d2b241] text-white px-5 py-3 rounded-xl font-semibold">
          Upload Document
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[1050px] w-full text-sm">
          <thead>
            <tr className="bg-[#d2b241] text-white">
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Document Name</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Date of Issue</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Date of Expiry</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Remaining Days</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Status</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Preview</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Download</th>
              <th className="px-2 py-2 text-left whitespace-nowrap text-sm">Delete</th>
            </tr>
          </thead>

          <tbody>
            {rows.length ? (
              rows.map((doc: any) => {
                const info = expiryInfo(doc.expiry_date);

                return (
                  <tr key={doc.id} className="border-b hover:bg-[#f7f4ec]">
                    <td className="p-3 font-semibold">{doc.document_name}</td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm">{doc.issue_date || "-"}</td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm">{doc.expiry_date || "No Expiry"}</td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm"><span className={`${info.className} px-3 py-1 rounded-full font-semibold`}>{info.daysText}</span></td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm"><span className={`${info.className} px-3 py-1 rounded-full font-semibold`}>{info.status}</span></td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm">{doc.file_data ? <button type="button" onClick={() => previewDoc(doc)} className="text-[#d2b241] font-bold">Preview</button> : "-"}</td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm">{doc.file_data ? <a href={doc.file_data} download={doc.file_name || doc.document_name} className="text-[#d2b241] font-bold">Download</a> : "-"}</td>
                    <td className="px-2 py-2 whitespace-nowrap text-sm"><button onClick={() => deleteDocument(doc.id)} className="bg-red-100 text-red-700 px-3 py-1 rounded-full font-bold">Delete</button></td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={8} className="p-5 text-center text-gray-500">
                  No {category.toLowerCase()} uploaded yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function expiryInfo(expiryDate: string | null) {
  if (!expiryDate) return { daysText: "No Expiry", status: "No Expiry", className: "bg-gray-100 text-gray-700" };

  const today = new Date();
  const expiry = new Date(expiryDate);
  const days = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (days < 0) return { daysText: `${Math.abs(days)} days expired`, status: "Expired", className: "bg-red-200 text-red-900" };
  if (days <= 30) return { daysText: `${days} days`, status: "Critical", className: "bg-red-100 text-red-700" };
  if (days <= 60) return { daysText: `${days} days`, status: "Warning", className: "bg-orange-100 text-orange-700" };
  if (days <= 90) return { daysText: `${days} days`, status: "Upcoming", className: "bg-yellow-100 text-yellow-700" };

  return { daysText: `${days} days`, status: "Available", className: "bg-green-100 text-green-700" };
}

function previewDoc(doc: any) {
  const w = window.open("", "_blank");

  if (w) {
    w.document.write(`<html><head><title>${doc.document_name}</title></head><body style="margin:0"><iframe src="${doc.file_data}" style="width:100%;height:100vh;border:0"></iframe></body></html>`);
    w.document.close();
  }
}

function MiniKpi({
  title,
  value,
  onClick,
}: {
  title: string;
  value: string;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      className={`w-full rounded-2xl border-t-4 border-[#d2b241] shadow-sm p-5 text-center transition ${
        onClick
          ? "cursor-pointer hover:shadow-md hover:-translate-y-0.5"
          : "cursor-default"
      }`}
    >
      <p className="text-gray-500 text-sm">{title}</p>
      <h3 className="text-2xl font-bold text-[#3f4447] mt-2">{value}</h3>
    </button>
  );
}

function InfoWide({ title, rows }: { title: string; rows: string[][] }) {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <h2 className="text-xl font-bold text-[#3f4447] mb-5">{title}</h2>
      {rows.map(([label, value]) => (
        <div key={label} className="flex justify-between border-b py-2 gap-4">
          <span className="text-gray-500">{label}</span>
          <b className="text-right">{value}</b>
        </div>
      ))}
    </section>
  );
}

function EditSection({ title, children }: { title: string; children: ReactNode }) {
  return <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6"><h2 className="text-xl font-bold text-[#3f4447] mb-5">{title}</h2><div className="grid grid-cols-1 md:grid-cols-2 gap-5">{children}</div></section>;
}

function EditInput({ label, field, value, update, type = "text" }: any) {
  return <div><label className="text-sm font-semibold text-gray-600">{label}</label><input type={type} value={value || ""} onChange={(e) => update(field, e.target.value)} className="mt-2 w-full border rounded-xl px-4 py-3 outline-none bg-white" /></div>;
}

function EditSelect({ label, field, value, options, update }: any) {
  return <div><label className="text-sm font-semibold text-gray-600">{label}</label><select value={value || ""} onChange={(e) => update(field, e.target.value)} className="mt-2 w-full border rounded-xl px-4 py-3 outline-none bg-white"><option value="">Select</option>{options.map((option: string) => <option key={option}>{option}</option>)}</select></div>;
}

function Input({ label, value, onChange, type = "text" }: any) {
  return <div><label className="text-sm font-semibold text-gray-600">{label}</label><input type={type} value={value || ""} onChange={(e) => onChange(e.target.value)} className="mt-2 w-full border rounded-xl px-4 py-3 outline-none bg-white" /></div>;
}

function Select({ label, value, options, onChange }: any) {
  return <div><label className="text-sm font-semibold text-gray-600">{label}</label><select value={value || ""} onChange={(e) => onChange(e.target.value)} className="mt-2 w-full border rounded-xl px-4 py-3 outline-none bg-white">{options.map((option: string) => <option key={option}>{option}</option>)}</select></div>;
}

function LeaveSection() {
  return <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6"><h2 className="text-xl font-bold text-[#3f4447] mb-5">Leave Applications & History</h2><p className="text-gray-500">Leave history will connect in the Leave Management phase.</p></section>;
}

function AuditSection({ status }: { status: string }) {
  return <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-10"><h2 className="text-xl font-bold text-[#3f4447] mb-5">Audit Log</h2><div className="space-y-3 text-sm"><p>✅ Employee profile loaded from Supabase.</p><p>✅ Current status: <b>{status}</b></p><p>✅ Edit, activate, deactivate, delete, and document actions are available.</p></div></section>;
}
