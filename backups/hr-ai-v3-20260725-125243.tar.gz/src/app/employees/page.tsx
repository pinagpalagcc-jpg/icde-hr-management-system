import { departments, getEmployees, getActiveLeaveEmployeeIds, displayStatus } from "@/lib/hr";
import ExportEmployeesButton from "@/components/ExportEmployeesButton";

export default async function EmployeesPage({
  searchParams,
}: {
  searchParams: Promise<{ department?: string; status?: string; view?: string }>;
}) {
  const params = await searchParams;
  const selectedDepartment = params.department || "";
  const selectedStatus = params.status || "";
  const showAll = params.view === "all";

  const employees = await getEmployees();
  const activeLeaveIds = await getActiveLeaveEmployeeIds();

  const filteredEmployees = employees.filter((employee: any) => {
    const matchesDepartment =
      !selectedDepartment || employee.department === selectedDepartment;

    const currentStatus = displayStatus(employee, activeLeaveIds);

    const matchesStatus =
      !selectedStatus || currentStatus === selectedStatus;

    return matchesDepartment && matchesStatus;
  });

  const shouldShowEmployees =
    showAll || Boolean(selectedDepartment) || Boolean(selectedStatus);

  return (
    <div className="min-h-screen bg-[#f7f4ec] flex">
      <Sidebar active="Employees" />

      <main className="flex-1 p-8 overflow-x-hidden">
        <h1 className="text-3xl font-bold text-[#3f4447]">Employees</h1>
        <p className="text-gray-500 mb-8">Select a department or use the dashboard cards to view employee records</p>

        <section className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-7 gap-4 mb-8">
          {departments.map((department) => {
            const count = employees.filter((e) => e.department === department).length;
            const active = selectedDepartment === department;

            return (
              <a
                key={department}
                href={`/employees?department=${encodeURIComponent(department)}`}
                className={`rounded-2xl shadow-sm px-4 py-4 text-center font-bold border-t-4 border-[#d2b241] hover:shadow-lg transition-all min-h-[96px] flex flex-col items-center justify-center ${
                  active ? "bg-[#d2b241] text-white" : "bg-white text-[#3f4447]"
                }`}
              >
                <div>{department}</div>
                <div className={`text-2xl mt-2 ${active ? "text-white" : "text-[#3f4447]"}`}>
                  {count}
                </div>
              </a>
            );
          })}
        </section>

        {!shouldShowEmployees ? (
          <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-10 text-center">
            <h2 className="text-xl font-bold text-[#3f4447]">Choose Department</h2>
            <p className="text-gray-500 mt-3">
              Click Clinicians, Admin, Front Desk, Dental Assistant, Insurance, House Keeping, or Dependants to view employees.
            </p>
            <a href="/employees/add" className="inline-block mt-8 bg-[#d2b241] text-white px-6 py-3 rounded-xl font-bold">
              Add Employee
            </a>
          </section>
        ) : (
          <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-4 mb-5">
              <h2 className="text-xl font-bold text-[#3f4447]">
                {selectedDepartment
                  ? `${selectedDepartment} Employees`
                  : selectedStatus
                  ? `${selectedStatus} Employees`
                  : "All Employees"}
              </h2>

              <div className="flex flex-wrap gap-3">
                <ExportEmployeesButton
                  fileName={
                    selectedDepartment
                      ? `${selectedDepartment}-employees`
                      : selectedStatus
                      ? `${selectedStatus}-employees`
                      : "all-employees"
                  }
                  employees={filteredEmployees.map((employee: any) => ({
                    employeeId: employee.employee_code || "",
                    name: `${employee.first_name || ""} ${employee.middle_name || ""} ${employee.last_name || ""}`
                      .replace(/\s+/g, " ")
                      .trim(),
                    department: employee.department || "",
                    position: employee.position || "",
                    phone: employee.mobile_number || "",
                    joiningDate: employee.joining_date || "",
                    status: displayStatus(employee, activeLeaveIds),
                  }))}
                />

                <a
                  href="/employees/add"
                  className="bg-[#d2b241] text-white px-5 py-3 rounded-xl font-bold"
                >
                  Add Employee
                </a>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-[1250px] w-full text-sm">
                <thead>
                  <tr className="bg-[#3f4447] text-white">
                    <th className="p-3 text-left min-w-[130px]">Employee ID</th>
                    <th className="p-3 text-left min-w-[260px]">Name</th>
                    <th className="p-3 text-left min-w-[180px]">Department</th>
                    <th className="p-3 text-left min-w-[200px]">Position</th>
                    <th className="p-3 text-left min-w-[180px] whitespace-nowrap">Phone</th>
                    <th className="p-3 text-left min-w-[150px] whitespace-nowrap">Joining Date</th>
                    <th className="p-3 text-left min-w-[130px]">Status</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredEmployees.length ? (
                    filteredEmployees.map((e) => {
                      const employeeName = `${e.first_name || ""} ${e.middle_name || ""} ${e.last_name || ""}`.replace(/\s+/g, " ").trim();

                      return (
                        <tr key={e.id} className="border-b hover:bg-[#f7f4ec]">
                          <td className="p-3 font-semibold">{e.employee_code}</td>
                          <td className="p-3">
                            <a href={`/employees/${e.id}`} className="text-[#d2b241] font-bold">
                              {employeeName}
                            </a>
                          </td>
                          <td className="p-3">{e.department}</td>
                          <td className="p-3">{e.position}</td>
                          <td className="p-3 whitespace-nowrap">{e.mobile_number}</td>
                          <td className="p-3 whitespace-nowrap">{e.joining_date}</td>
                          <td className="p-3">
                            {(() => {
                              const currentStatus = displayStatus(
                                e,
                                activeLeaveIds
                              );

                              return (
                                <span
                                  className={`${
                                    currentStatus === "On Leave"
                                      ? "bg-orange-100 text-orange-700"
                                      : currentStatus === "Inactive"
                                      ? "bg-red-100 text-red-700"
                                      : "bg-green-100 text-green-700"
                                  } px-3 py-1 rounded-full font-semibold`}
                                >
                                  {currentStatus}
                                </span>
                              );
                            })()}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-gray-500">
                        No employees found for the selected filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

function Sidebar({ active }: { active: string }) {
  const items = [
    ["Dashboard", "/dashboard"],
    ["Employees", "/employees"],
    ["Messenger", "/messenger"],
    ["Leave Requests", "/leave-requests"],
    ["Document Expiry", "/document-expiry"],
    ["Reports", "/reports"],
    ["HR AI Assistant", "/hr-ai-assistant"],
  ];

  return (
    <aside className="w-72 shrink-0 bg-[#3f4447] text-white p-6 hidden md:flex flex-col justify-between">
      <div>
        <div className="mb-10">
          <div className="text-4xl font-black tracking-widest">
            <span className="text-white">IC</span><span className="text-[#d2b241]">D</span><span className="text-white">E</span>
          </div>
          <div className="text-sm text-white/90 mt-3">HR Management Portal</div>
          <div className="w-24 h-[3px] bg-[#d2b241] mt-3 rounded-full"></div>
          <div className="text-xs text-white/60 mt-3">@2026 V.1.1</div>
        </div>

        <nav className="space-y-3">
          {items.map(([name, href]) => (
            <a
              key={name}
              href={href}
              className={`block px-4 py-3 rounded-xl ${
                active === name ? "bg-[#d2b241] font-semibold" : "hover:bg-white/10"
              }`}
            >
              {name}
            </a>
          ))}
        </nav>
      </div>

      <a href="/login" className="block text-center w-full rounded-2xl border border-white/25 py-4 text-white font-semibold hover:bg-white/10">
        Sign Out
      </a>
    </aside>
  );
}
