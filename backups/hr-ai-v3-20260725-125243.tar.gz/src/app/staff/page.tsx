"use client";

import { useEffect, useState } from "react";

import StaffSidebar from "@/components/StaffSidebar";
export default function StaffDashboardPage() {
  const [employee, setEmployee] = useState<any>(null);
  const [
    isImpersonating,
    setIsImpersonating,
  ] = useState(false);

  const [expiryAlerts, setExpiryAlerts] = useState<any[]>([]);
  const [annualLeaveSummary, setAnnualLeaveSummary] = useState({
    used: 0,
    balance: 0,
  });

  useEffect(() => {
    async function initializeStaff() {
      try {
        const response = await fetch(
          "/api/auth/session",
          {
            credentials: "include",
            cache: "no-store",
          }
        );

        if (!response.ok) {
          window.location.href = "/logout";
          return;
        }

        const session = await response.json();

        setIsImpersonating(
          Boolean(session.isImpersonating)
        );

        const id =
          session.userId || session.id || "";

        if (!id || session.role !== "Staff") {
          window.location.href = "/logout";
          return;
        }

        localStorage.setItem(
          "icde_user_id",
          id
        );
        localStorage.setItem(
          "icde_user_role",
          "Staff"
        );

        await loadStaff(id);
      } catch {
        window.location.href = "/logout";
      }
    }

    initializeStaff();
  }, []);

  async function returnToAdmin() {
    const response = await fetch(
      "/api/auth/return-to-admin",
      {
        method: "POST",
        credentials: "include",
      }
    );

    const result = await response.json();

    if (!response.ok) {
      alert(
        result.error ||
          "Unable to return to Admin."
      );
      return;
    }

    localStorage.setItem(
      "icde_user_role",
      "Admin"
    );

    window.location.href =
      "/dashboard";
  }

  async function loadStaff(id: string) {
    const [employeeResponse, documentsResponse, leaveResponse] =
      await Promise.all([
        fetch(`/api/employees/${id}`, {
          cache: "no-store",
        }),
        fetch(
          `/api/employee-documents?employee_id=${id}`,
          {
            cache: "no-store",
          }
        ),
        fetch("/api/leave-requests", {
          cache: "no-store",
        }),
      ]);

    const emp = await employeeResponse.json();
    const docs = await documentsResponse.json();
    const leaveData = await leaveResponse.json();

    setEmployee(emp);

    const annualGroupTypes = [
      "Annual Leave",
      "Sick Leave",
      "Emergency Leave",
  "Encash Leave",
    ];

    const approvedAnnualRequests = Array.isArray(leaveData)
      ? leaveData.filter((request: any) => {
          return (
            String(request.employee_id) === String(id) &&
            String(request.status).toLowerCase() ===
              "approved" &&
            annualGroupTypes.includes(
              String(request.leave_type)
            )
          );
        })
      : [];

    const used = approvedAnnualRequests.reduce(
      (total: number, request: any) =>
        total + Number(request.total_days || 0),
      0
    );

    const entitlement = Number(emp.total_leaves ?? 0);

    setAnnualLeaveSummary({
      used,
      balance: Math.max(entitlement - used, 0),
    });

    const alerts = (docs || [])
      .filter((d: any) => d.expiry_date)
      .map((d: any) => {
        const days = daysRemaining(d.expiry_date);
        return { ...d, remaining: days };
      })
      .filter((d: any) => d.remaining >= 0 && d.remaining <= 90)
      .sort((a: any, b: any) => a.remaining - b.remaining);

    setExpiryAlerts(alerts);
  }

  if (!employee) return <div className="p-10">Loading Staff Dashboard...</div>;

  const name = `${employee.first_name || ""} ${employee.middle_name || ""} ${employee.last_name || ""}`.replace(/\s+/g, " ").trim();

  return (
    <div className="min-h-screen bg-[#f7f4ec] flex">
      <StaffSidebar active="Dashboard" employeeId={employee.id} />

      <main className="flex-1 p-8 overflow-x-hidden">
        {isImpersonating && (
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border-2 border-purple-400 bg-purple-50 p-5">
            <div>
              <p className="font-bold text-purple-800">
                Admin Testing Mode
              </p>
              <p className="text-sm text-purple-700">
                You are testing the Staff Portal as {name}. Actions such as applying leave create real records.
              </p>
            </div>

            <button
              onClick={returnToAdmin}
              className="rounded-xl bg-purple-700 px-5 py-3 font-semibold text-white"
            >
              Return to Admin
            </button>
          </div>
        )}

        <h1 className="text-3xl font-bold text-[#3f4447]">Staff Dashboard</h1>
        <p className="text-gray-500 mb-8">Welcome, {name}</p>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Kpi title="Total Leaves" value={`${employee.total_leaves ?? 0} Days`} />
          <Kpi
            title="Leaves Used"
            value={`${annualLeaveSummary.used} Days`}
          />
          <Kpi
            title="Balance Leaves"
            value={`${annualLeaveSummary.balance} Days`}
          />
        </section>

        <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
          <h2 className="text-xl font-bold text-[#3f4447] mb-5">Upcoming My Document Expiry - 90 Days Alert</h2>

          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#d2b241] text-white">
                <th className="p-3 text-left">Document</th>
                <th className="p-3 text-left">Category</th>
                <th className="p-3 text-left">Expiry Date</th>
                <th className="p-3 text-left">Remaining Days</th>
              </tr>
            </thead>
            <tbody>
              {expiryAlerts.length ? expiryAlerts.map((d) => (
                <tr key={d.id} className="border-b">
                  <td className="p-3 font-semibold">{d.document_name}</td>
                  <td className="p-3">{d.category}</td>
                  <td className="p-3">{d.expiry_date}</td>
                  <td className="p-3"><span className={`${expiryBadgeClass(d.remaining)} px-3 py-1 rounded-full font-semibold`}>{d.remaining} days</span></td>
                </tr>
              )) : (
                <tr><td colSpan={4} className="p-6 text-center text-gray-500">No upcoming document expiry alerts.</td></tr>
              )}
            </tbody>
          </table>
        </section>
      </main>
    </div>
  );
}

function daysRemaining(dateValue: string) {
  const today = new Date();
  const expiry = new Date(dateValue);
  return Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function expiryBadgeClass(days: number) {
  if (days <= 30) return "bg-red-100 text-red-700";
  if (days <= 60) return "bg-orange-100 text-orange-700";
  return "bg-purple-100 text-purple-700";
}

function Kpi({ title, value }: { title: string; value: string | number }) {
  return <div className="bg-white rounded-2xl p-5 shadow-sm border-t-4 border-[#d2b241] text-center"><p className="text-gray-500 text-sm font-medium">{title}</p><h3 className="text-2xl font-bold text-[#3f4447] mt-2">{value}</h3></div>;
}
