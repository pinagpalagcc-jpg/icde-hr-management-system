"use client";

import { useState } from "react";

export default function ChangePasswordPage() {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);

  async function changePassword() {
    if (saving) return;

    if (newPassword.length < 8) {
      alert(
        "Password must be at least 8 characters."
      );
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    setSaving(true);

    try {
      const response = await fetch(
        "/api/auth/change-password",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            newPassword,
            confirmPassword,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        alert(
          result.error ||
            "Password change failed."
        );

        if (response.status === 401) {
          window.location.href = "/login";
        }

        return;
      }

      alert("Password changed successfully.");

      window.location.href =
        result.role === "Admin"
          ? "/dashboard"
          : "/staff";
    } catch {
      alert("Password change failed.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#f7f4ec] flex items-center justify-center p-6">
      <section className="w-full max-w-xl bg-white rounded-3xl shadow-lg p-10">
        <h1 className="text-3xl font-bold text-[#3f4447] mb-2">Change Password</h1>
        <p className="text-gray-500 mb-8">Create your new password before continuing.</p>

        <div className="space-y-5">
          <div>
            <label className="text-sm font-semibold text-gray-600">New Password</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="mt-2 w-full border rounded-xl px-4 py-3 outline-none"
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-gray-600">Confirm Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="mt-2 w-full border rounded-xl px-4 py-3 outline-none"
            />
          </div>

          <button
            onClick={changePassword}
            disabled={saving}
            className="w-full bg-[#d2b241] text-white rounded-xl py-3 font-bold disabled:opacity-60"
          >
            {saving ? "Saving..." : "Save New Password"}
          </button>
        </div>
      </section>
    </div>
  );
}
